<!-- https://www.tutorialrepublic.com/php-tutorial/php-json-parsing.php -->
<?php
header('Content-type: text/javascript');
// Store JSON data in a PHP variable
// By default the json_decode() function returns an object.
//  However, you can optionally specify a second parameter $assoc 
//  which accepts a boolean value that when set as true JSON objects 
//  are decoded into associative arrays. It is false
$json = '{"Peter":65,"Harry":80,"John":78,"Clark":90}'; 
var_dump(json_decode($json));
?>