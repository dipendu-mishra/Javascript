let selectedRow = null;
// fun declaration on form submit
function formSubmit(){
      // fun call to read form data
      let formData = readFormData();
      console.log(formData);
      if(selectedRow == null){
            // fun call to insert record
            insertRecord(formData);
      }
      else{
            // fun call to update data
            updateData(formData);
      }
      // fun call to reset form
      resetForm();
}

// fun declaration to read form data
function readFormData(){
      // initialize empty object and access req ele.s
      let formData = {};
      formData['roll'] = document.getElementById('roll').value;
      formData['name'] = document.getElementById('name').value;
      formData['dept'] = document.getElementById('dept').value;
      formData['salary'] = document.getElementById('salary').value;
      formData['dept1'] = document.getElementById('dept1').value;
      formData['salary1'] = document.getElementById('salary1').value;
      return formData;
}

// fun declaration to insert data
function insertRecord(data){
      // access required elements
      let table = document.getElementById('myTable');
      // insert new row
      let row = table.insertRow(table.length);
      // insert cells and form data
      let cell1 = row.insertCell(0);
      cell1.innerHTML = data.roll;
      let cell2 = row.insertCell(1);
      cell2.innerHTML = data.name;
      let cell3 = row.insertCell(2);
      cell3.innerHTML = data.dept;
      let cell4 = row.insertCell(3);
      cell4.innerHTML = data.salary;
      let cell5 = row.insertCell(4);
      cell5.innerHTML = `<button class ="btn btn-success" onclick = "edit(this)">Edit</button>
                         <button class ="btn btn-danger" onclick = "dlt(this)">Delete</button>`
}

// fun declaration to reset form
function resetForm(){
      // access form ele.s and set to empty value
      document.getElementById('roll').value = '';
      document.getElementById('name').value = '';
      document.getElementById('dept').value = '';
      document.getElementById('salary').value = '';
}

// fun declaration to edit selected row data
function edit(td){
      // access tr and editorBox ele.s
      let selectedRow = td.parentElement.parentElement;
      console.log(selectedRow);
      let editorBox = document.querySelector('.editorBox');
      editorBox.style.display = 'block';
      document.getElementById('dept1').value = selectedRow.cells[2].innerHTML;
      document.getElementById('salary1').value = selectedRow.cells[3].innerHTML;
      let inc = document.getElementById('inc').value = 0;   
}
// fun declaration to update data
function updateData(data){
      selectedRow.cells[2].innerHTML = data.dept1;
      selectedRow.cells[3].innerHTML = data.salary1;
}

